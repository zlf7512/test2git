# _*_ codeing:utf-8 _*_
# 开发团队:福州通和
# 开发人员:zengl
#开发时间:2019-04-2614:30 
#文件名称:views.py
from flask import Flask,jsonify,request
from flask import make_response
from flask_cors import CORS
import sys
import json



app = Flask(__name__)
CORS(app, supports_credentials=True)
import logic


#获取登入信息
@app.route('/get',methods=['GET'])
def home_page():
    if not request.args or not 'name' in request.args:
      abort(400)
    name = request.args.get("name")
    password =  request.args.get("pass")
    is_login=logic.getuseifno(name,password)
    #print(is_login)
    return is_login
#获取商品类别
@app.route('/getcategory',methods=['GET'])
def get_category():
    is_login=logic.getcategory()
    #print(is_login)
    return "["+is_login+"]"

#获取sku所有商品信息
@app.route('/getskugoodsall',methods=['GET'])
def get_skugoodsall():
    par = request.args.get("par")
    spxx=logic.getskugoodsall(par)
   # return "ok"
    return "["+spxx+"]"
#提交订单
@app.route('/postordertail',methods=['POST'])
def post_orderdetail():
    if request.method == 'POST':
      result=logic.postorder( json.loads(request.data))
      print(result)
      return  result
#获取订单列表
@app.route('/getorderlist',methods=['GET'])
def get_orderlist():
    start = request.args.get("start")
    end = request.args.get("end")
    customer = request.args.get("customer")
    print(start)
    result = logic.getorderlist(start,end,customer)
    return  "["+result+"]"
#获取订单明细
@app.route('/getorderdetail',methods=['GET'])
def get_orderdetail():
    sheetno = request.args.get("sheetno")
    result = logic.getorderdetail(sheetno)
    return  "["+result+"]"
