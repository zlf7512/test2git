# _*_ codeing:utf-8 _*_
# 开发团队:福州通和
# 开发人员:zengl
#开发时间:2019-04-2614:30 
#文件名称:logic
import pymssql,json
from decimal import *
import time
import datetime

class SQLServer:
      def __init__(self):
      # 类的构造函数，初始化DBC连接信息
         self.server = '116.62.61.195:7777'
         self.user = 'sa'
         self.password = 'fzthzn'
         self.database = 'isszmv10_fzjlgyz'

      def __getconnect(self):
          if not self.database:
              raise (NameError, "没有设置数据库信息")
          self.conn = pymssql.connect(server=self.server, user=self.user, password=self.password,
                                      database=self.database)
          print (self.conn)
          cur = self.conn.cursor()
          if not cur:
              raise (NameError, "连接数据库失败")  # 将DBC信息赋值给cur
          else:
              return cur

      def ExecQuery(self, sql) :
          cur = self.__getconnect()
          cur.execute(sql)
          result = cur.fetchall()
          self.conn.close()
          return result

      def excqurey(sql,parms):
        try:
            jsondata = []
            curr =SQLServer()
            result = curr.ExecQuery(sql)
            for row in result:
                result_1={}
                i = 0
                for parm in parms:
                    detail_data=row[i]
                    if(isinstance(detail_data,Decimal)):

                        result_1[parm]=str(row[i])
                    elif(isinstance(detail_data,datetime.datetime)):

                        result_1[parm] = row[i].strftime('%Y-%m-%d %H:%M:%S')
                    else:
                        result_1[parm] = row[i]
                    i = i+1

                jsondata.append(result_1)

        except:
            raise(NameError, "connect flase")
        else:
            jsondatar = json.dumps(jsondata, ensure_ascii=False)

            return jsondatar[1:len(jsondatar) - 1]


      def smailexcqurey(sql):
            try:
                curr = SQLServer()
                result = curr.ExecQuery(sql)
            except:
                raise (NameError, "connect flase")
            else:
                return result


#读取客户信息
def getuseifno(name,password):
    jsondatar=SQLServer.excqurey(
        r"select mobile,sup_name,supcust_no from t_bd_supcust_info where supcust_flag='C'  and mobile='"+name+"' and  sup_acct_no='"+password+"'",
        ["mobile","sup_name","supcust_no"])
    return jsondatar
#读取商品类别表
def getcategory():
    jsondatar = SQLServer.excqurey(
        r"select item_clsno=rtrim(item_clsno),item_clsname=rtrim(item_clsname) from dbo.t_bd_item_cls where item_clsno<>'LB'",
        ["item_clsno", "item_clsname"])
   # print(jsondatar)
    return jsondatar
#get sku下所有商品信息
def getskugoodsall(par):
    str ="item_no,item_name,unit_no,item_size,item_clsno,item_rem,appointed_price,cls_name,orderqty"
    arr= str.split(',')
    #print (arr)
    jsondatar = SQLServer.excqurey( r"select item_no=rtrim(sp.item_no),item_name=sp.item_name,unit_no=rtrim(sp.unit_no),item_size=sp.item_size,item_clsno=rtrim(sp.item_clsno),item_rem=sp.item_rem,appointed_price=kh.appointed_price,cls_name=(select item_clsname from t_bd_item_cls where item_clsno=sp.item_clsno ),orderqty=1 from dbo.t_bd_supcust_item kh,t_bd_item_info sp where supcust_no='01000001' and sp.item_no=kh.item_no ",
        arr)

    return jsondatar

def getsheetno():
    res = SQLServer.smailexcqurey( r"select sheet_value=right(sheet_value+1,4) from t_sys_sheet_no where sheet_id='SS'")

    liusui_no= res[0][0]
    befor_long=4-len(liusui_no)
   # print(befor_long)
    if(befor_long>0):
          i = 1
          s = ''
          while i <= befor_long:
              s="0"+s
              i=i+1
          sheet_no=time.strftime('%Y%m%d',time.localtime(time.time()))
          sheet_no="SS000"+sheet_no[2:8]+s+liusui_no
          return  sheet_no
#获取订单列表
def getorderlist(start,end,customer):
    str = "sheet_no,sheet_amt,oper_date,branch"
    arr = str.split(',')

    jsondatar = SQLServer.excqurey(
        r"select sheet_no ,sheet_amt,oper_date,branch=(select branch_name from t_bd_branch_info  where branch_no=t_wm_sheet_master.branch_no)  from t_wm_sheet_master where supcust_no='"+customer+"' and oper_date>='"+start+"' and oper_date<='"+end+"'  and approve_flag='1' ",
        arr)
    return jsondatar
#获取订单明细
def getorderdetail(sheetno):
    str = "sheet_no,item_no,item_name,unit_no,item_size,valid_price,real_qty,sub_amt"
    arr = str.split(',')

    jsondatar = SQLServer.excqurey(
        r"select a.sheet_no,a.item_no,b.item_name,b.unit_no,item_size,valid_price=round(valid_price,2),real_qty=round(real_qty,2),sub_amt=round(sub_amt,2) from t_wm_sheet_detail a,t_bd_item_info b where a.item_no=b.item_no and a.sheet_no='"+sheetno+"' ",
        arr)
    print(jsondatar)
    return jsondatar



def postorder(res):
    customer = res["customer"]
    order_date = res["order_date"]
    total_amt =res["total_amt"]
    detail_amt = res["order_detail"]

    sheet_no=getsheetno()
    conn = pymssql.connect('116.62.61.195:7777',  'sa', 'fzthzn', 'isszmv10_fzjlgyz')
    cursor = conn.cursor()
    try:
      cursor.execute(r"insert into t_wm_sheet_master(sheet_no,trans_no,db_no,branch_no,supcust_no,pay_way,coin_no,paid_amt,order_status,approve_flag,oper_id,oper_date,valid_date,sheet_amt,com_flag,total_money) values ('%s','SS','-','000001','%s','RMB','RMB','0','0','0','1001','%s','%s',%d,'0','0')"
                   %(sheet_no,customer,order_date,order_date,int(total_amt)))
      for item in detail_amt:
        item_no = item["item_no"]
        orderqty = item["orderqty"]
        appointed_price = item["appointed_price"]
        item_amt = item["item_amt"]
        cursor.execute(r"insert into t_wm_sheet_detail(sheet_no,item_no,orgi_price,valid_price,order_qty,real_qty,large_qty,sub_amt,tax,cost_price,send_qty,sale_price,num1,come_num) values('%s','%s',%s,%s,0,%s,%s,%s,0.17,0,0,0,1,0)"
                       %(sheet_no,item_no,appointed_price,appointed_price,orderqty,orderqty,item_amt))
      cursor.execute(r"UPDATE t_wm_sheet_master set approve_flag=1,confirm_man='1001',work_date=getdate()  where sheet_no='%s'" %(sheet_no) )
      cursor.execute(r"UPDATE t_sys_sheet_no set sheet_value=sheet_value+1 from t_sys_sheet_no where sheet_id='SS'")
      conn.commit()
      reslut =[]
      result_2 = {}
      result_2["msg"] = "ok"
      result_2["code"] = "200"
      result_2["sheet_no"] = sheet_no
      reslut.append(result_2)
      reslut = json.dumps(reslut, ensure_ascii=False)
      return reslut[1:len(reslut) - 1]

    except Exception as e :
        print(e)
        conn.rollback()
        reslut = []
        result_2 = {}
        result_2["msg"] = "flase"
        result_2["code"] = "400"
        result_2["sheet_no"] = ""
        reslut.append(result_2)
        reslut = json.dumps(reslut, ensure_ascii=False)
        return reslut[1:len(reslut) - 1]

    finally:
     conn.close()







if __name__ == '__main__':
    getsheetno()  #测试方法